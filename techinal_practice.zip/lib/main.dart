import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:techinal_practice/controller/api/newscontroller.dart';
import 'package:techinal_practice/controller/json/album_provider.dart';
import 'package:get/get.dart';
import 'package:techinal_practice/views/api/newshome.dart';
import 'package:techinal_practice/views/json/album_home_page.dart';
import 'package:techinal_practice/views/json/details_page.dart';
import 'package:techinal_practice/views/json/homepage.dart';
import 'package:techinal_practice/views/json/sholak_page.dart';

import 'controller/json/chepter_provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => ChepterProvider(),
        ),
        ChangeNotifierProvider(
          create: (context) => AlbumProvider(),
        ),
        ChangeNotifierProvider(
          create: (context) => NewsProvider(),
        ),
      ],
      builder: (context, child) {
        return GetMaterialApp(
          debugShowCheckedModeBanner: false,
          initialRoute: "/News_home",
          getPages: [
            GetPage(
              name: "/",
              page: () => HomePage(),
            ),
            GetPage(
              name: "/Sholak_page",
              page: () => Sholak_page(),
            ),
            GetPage(
              name: "/SholakDetailPage",
              page: () => SholakDetailPage(),
            ),
            GetPage(
              name: "/Album_home",
              page: () => Album_home(),
            ),
            GetPage(
              name: "/News_home",
              page: () => News_home(),
            ),
          ],
        );
      },
    ),
  );
}
