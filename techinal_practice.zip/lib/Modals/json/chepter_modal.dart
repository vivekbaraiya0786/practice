
import 'package:techinal_practice/Modals/json/verse_modal.dart';

class ChepterModal{
  List<Verse> chepter = [];

  ChepterModal({required this.chepter});
}