import 'package:techinal_practice/Modals/json/album_modal.dart';
import 'package:techinal_practice/Modals/json/verse_modal.dart';

class AlbumModal{
  List<Album> album = [];

  AlbumModal({required this.album});
}