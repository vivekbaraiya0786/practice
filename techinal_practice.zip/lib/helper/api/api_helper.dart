import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../Modals/api/news_modal.dart';

class ApiHelper{
  ApiHelper._();
  static final ApiHelper apiHelper =ApiHelper._();

  Future<News?> fetchNews(String country,String category)async{
    String baseUrl  = "https://newsapi.org/v2/top-headlines?country=$country&category =$category&apiKey=80efab41678840cc9a5ccc0dd8060dd5";
    http.Response res = await http.get(Uri.parse(baseUrl));
    print("Res : $res");

    if(res.statusCode == 200){
      print(res.statusCode);

      String data = res.body;
      print("body : ${res.body}");
      Map<String,dynamic>  decodeList = jsonDecode(data);
      News news = News.fromJson(json: decodeList);
      return news;
    }
    return null;
  }
}